package handler

import (
	"github.com/open-runtimes/types-for-go/v4/openruntimes"
)

// This Appwrite function will be executed every time your function is triggered
func Main(Context openruntimes.Context) openruntimes.Response {
	return Context.Res.Json(struct{ Hello string }{
		Hello: "World",
	})
}
